/* ghpc.hpp
 * libghpc main include header - C++
 * 
 * Copyright (c) 2014-2016, polarysekt
 */

extern "C" {
#include "ghpc.h"
}

